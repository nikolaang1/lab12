package mk.ukim.finki.wp.lab.model;

public class EventBooking {
    String eventName;
    String attendeeName;
    String atendeeAdress;
    Long numberOfTickets;
}
